package com.example.gymtracker

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import android.os.CountDownTimer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONObject
import java.util.Locale

private data class Exercise(val name: String, val sets: Int, val reps: String)
private data class WorkoutDay(val id: String, val title: String, val subtitle: String, val exercises: List<Exercise>)

private val workoutDays = listOf(
    WorkoutDay("push", "يوم الدفع", "صدر • كتف • تراي", listOf(
        Exercise("بار مستوي",3,"8-10"), Exercise("تجميع عالي بالدمبل",3,"10"),
        Exercise("تجميع سفلي أو متوازي",3,"10"), Exercise("تفتيح كروس أوفر",3,"12-15"),
        Exercise("رفرفة جانبي للكتف",4,"12-15"), Exercise("رفرفة أمامي",3,"12"),
        Exercise("دفع تراي لأسفل بالكابل",3,"12"), Exercise("تراي فرنساوي خلف الرأس",3,"12")
    )),
    WorkoutDay("pull", "يوم السحب", "ظهر • كتف خلفي • باي • ساعد", listOf(
        Exercise("سحب عالي أمامي",3,"10-12"), Exercise("سحب أرضي",3,"10-12"),
        Exercise("سحب طرمبة بالدمبل",3,"10"), Exercise("فيس بول للكتف الخلفي",3,"15"),
        Exercise("شرجز ترابيس",3,"15"), Exercise("تبادل باي بالدمبل",3,"10"),
        Exercise("باي شاكوش",3,"10"), Exercise("معصم للساعد",3,"15")
    )),
    WorkoutDay("legs", "يوم الأرجل", "أرجل • بطن", listOf(
        Exercise("سكوات",4,"8-10"), Exercise("مكبس أرجل",3,"10-12"),
        Exercise("ديدليفت روماني",3,"8-10"), Exercise("رفرفة أمامي جهاز",3,"12-15"),
        Exercise("سحب خلفي جهاز",3,"12-15"), Exercise("سمانة جهاز",4,"15-20"),
        Exercise("بطن علوي (Crunches)",3,"15-20"), Exercise("رفع أرجل للبطن السفلي",3,"15")
    ))
)

private val Bg = Color(0xFF0B1020)
private val CardBg = Color(0xFF151D31)
private val Accent = Color(0xFF45D6A5)
private val Muted = Color(0xFF9AA8BF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GymTrackerApp() }
    }
}

@Composable
private fun GymTrackerApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("gym_tracker", 0) }
    var selectedDay by remember { mutableStateOf<WorkoutDay?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    var showWeekReset by remember { mutableStateOf(false) }

    fun checked(day: WorkoutDay, index: Int): Boolean =
        prefs.getBoolean("${day.id}_$index", false)

    fun completed(day: WorkoutDay): Int = day.exercises.indices.count { checked(day, it) }
    val total = workoutDays.sumOf { it.exercises.size }
    val done = workoutDays.sumOf { completed(it) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Bg, surface = CardBg,
        onBackground = Color.White, onSurface = Color.White
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = Bg) {
                if (selectedDay == null) {
                    HomeScreen(
                        done = done, total = total,
                        onSelect = { selectedDay = it },
                        onWeekReset = { showWeekReset = true },
                        completed = ::completed
                    )
                } else {
                    DayScreen(
                        day = selectedDay!!,
                        isChecked = ::checked,
                        onToggle = { day, index, value ->
                            prefs.edit().putBoolean("${day.id}_$index", value).apply()
                            refresh++
                        },
                        onReset = { day ->
                            val editor = prefs.edit()
                            day.exercises.indices.forEach { editor.remove("${day.id}_$it") }
                            editor.apply()
                            refresh++
                        },
                        onBack = { selectedDay = null },
                        refresh = refresh
                    )
                }

                if (showWeekReset) {
                    AlertDialog(
                        onDismissRequest = { showWeekReset = false },
                        title = { Text("بدء أسبوع جديد؟") },
                        text = { Text("سيتم تصفير علامات الإنجاز للأيام الثلاثة. لن يتم حذف الأوزان والملاحظات.") },
                        confirmButton = {
                            TextButton(onClick = {
                                val editor = prefs.edit()
                                workoutDays.forEach { day -> day.exercises.indices.forEach { editor.remove("${day.id}_$it") } }
                                editor.apply()
                                refresh++
                                showWeekReset = false
                            }) { Text("إعادة ضبط الأسبوع") }
                        },
                        dismissButton = { TextButton(onClick = { showWeekReset = false }) { Text("إلغاء") } }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    done: Int, total: Int, onSelect: (WorkoutDay) -> Unit,
    onWeekReset: () -> Unit, completed: (WorkoutDay) -> Int
) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FitnessCenter, null, tint = Accent, modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("GYM TRACKER", color = Accent, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Text("خطوتك نحو أداء أفضل", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(24.dp))
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("إنجازك هذا الأسبوع", color = Muted)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$done", style = MaterialTheme.typography.displaySmall, color = Accent, fontWeight = FontWeight.Bold)
                    Text(" / $total تمرين", color = Muted, modifier = Modifier.padding(start = 8.dp, bottom = 7.dp))
                }
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { if (total == 0) 0f else done.toFloat() / total },
                    modifier = Modifier.fillMaxWidth().height(9.dp),
                    color = Accent, trackColor = Color(0xFF303B52)
                )
                Text("${(done * 100 / total)}٪ مكتمل", color = Muted, modifier = Modifier.padding(top = 8.dp))
            }
        }
        Spacer(Modifier.height(22.dp))
        Text("اختر يوم التمرين", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        workoutDays.forEachIndexed { index, day ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onSelect(day) },
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).background(Color(0xFF20334A), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Text(listOf("01","02","03")[index], color = Accent, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(day.title, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(day.subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${completed(day)}/${day.exercises.size}", color = Accent, fontWeight = FontWeight.Bold)
                        Text("تمارين", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onWeekReset, modifier = Modifier.fillMaxWidth()) {
            Text("إعادة ضبط الأسبوع")
        }
        Text("بياناتك محفوظة على الهاتف • يعمل بدون إنترنت", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 12.dp))
    }
}

@Composable
private fun DayScreen(
    day: WorkoutDay,
    isChecked: (WorkoutDay, Int) -> Boolean,
    onToggle: (WorkoutDay, Int, Boolean) -> Unit,
    onReset: (WorkoutDay) -> Unit,
    onBack: () -> Unit,
    refresh: Int
) {
    var showReset by remember { mutableStateOf(false) }
    var showTimer by remember { mutableStateOf(false) }
    var expandedIndex by remember { mutableIntStateOf(-1) }
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("gym_tracker", 0) }
    val done = day.exercises.indices.count { isChecked(day, it) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "رجوع", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(day.title, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(day.subtitle, color = Muted)
            }
            IconButton(onClick = { showTimer = true }) { Icon(Icons.Default.Timer, "مؤقت الراحة", tint = Accent) }
        }
        Spacer(Modifier.height(12.dp))
        LinearProgressIndicator(
            progress = { done.toFloat() / day.exercises.size },
            modifier = Modifier.fillMaxWidth().height(8.dp),
            color = Accent, trackColor = Color(0xFF303B52)
        )
        Text("$done من ${day.exercises.size} تمارين مكتملة", color = Muted, modifier = Modifier.padding(vertical = 10.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            itemsIndexed(day.exercises) { index, exercise ->
                key(refresh) {
                    Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().clickable { expandedIndex = if (expandedIndex == index) -1 else index }.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = isChecked(day, index),
                                    onCheckedChange = { onToggle(day, index, it) },
                                    colors = CheckboxDefaults.colors(checkedColor = Accent, uncheckedColor = Muted)
                                )
                                Spacer(Modifier.width(6.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(exercise.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                    Text("${exercise.sets} مجاميع × ${exercise.reps} عدة", color = Muted, style = MaterialTheme.typography.bodySmall)
                                }
                                Text(if (isChecked(day,index)) "مكتمل" else "تفاصيل", color = if (isChecked(day,index)) Accent else Muted, style = MaterialTheme.typography.labelSmall)
                            }
                            if (expandedIndex == index) {
                                Divider(color = Color(0xFF303B52), modifier = Modifier.padding(vertical = 8.dp))
                                var weight by remember { mutableStateOf(prefs.getString("${day.id}_${index}_weight", "") ?: "") }
                                var note by remember { mutableStateOf(prefs.getString("${day.id}_${index}_note", "") ?: "") }
                                OutlinedTextField(
                                    value = weight, onValueChange = { weight = it; prefs.edit().putString("${day.id}_${index}_weight", it).apply() },
                                    label = { Text("الوزن المستخدم (كجم)") }, modifier = Modifier.fillMaxWidth(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true
                                )
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = note, onValueChange = { note = it; prefs.edit().putString("${day.id}_${index}_note", it).apply() },
                                    label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth(), minLines = 2
                                )
                                Spacer(Modifier.height(12.dp))
                                ExerciseVideoSection(
                                    savedUri = prefs.getString("${day.id}_${index}_video", null),
                                    onVideoSelected = { uri ->
                                        prefs.edit().putString("${day.id}_${index}_video", uri.toString()).apply()
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
        OutlinedButton(onClick = { showReset = true }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 12.dp)) {
            Text("إعادة ضبط اليوم")
        }
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("إعادة ضبط ${day.title}") },
            text = { Text("هل تريد إزالة علامات الصح لهذا اليوم؟") },
            confirmButton = {
                TextButton(onClick = { onReset(day); showReset = false }) { Text("إعادة الضبط") }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("إلغاء") } }
        )
    }
    if (showTimer) RestTimerDialog(onDismiss = { showTimer = false })
}

@Composable
private fun ExerciseVideoSection(
    savedUri: String?,
    onVideoSelected: (Uri) -> Unit
) {
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some document providers do not support persistable permissions.
            }
            onVideoSelected(uri)
        }
    }

    Text("فيديو شرح التمرين", color = Color.White, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(6.dp))
    OutlinedButton(
        onClick = { picker.launch(arrayOf("video/*")) },
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(if (savedUri == null) "＋ إضافة فيديو من الهاتف" else "تغيير الفيديو")
    }

    if (savedUri != null) {
        Spacer(Modifier.height(8.dp))
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp),
            factory = { viewContext ->
                VideoView(viewContext).apply {
                    setMediaController(MediaController(viewContext).also { it.setAnchorView(this) })
                    tag = null
                }
            },
            update = { videoView ->
                if (videoView.tag != savedUri) {
                    videoView.tag = savedUri
                    videoView.setVideoURI(Uri.parse(savedUri))
                }
            }
        )
        Text(
            "اضغط تشغيل داخل الفيديو لمشاهدة الشرح.",
            color = Muted,
            style = MaterialTheme.typography.bodySmall
        )
    } else {
        Text(
            "اختر فيديو قصيرًا من جهازك ليظهر هنا لهذا التمرين فقط.",
            color = Muted,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun RestTimerDialog(onDismiss: () -> Unit) {
    var seconds by remember { mutableIntStateOf(90) }
    var remaining by remember { mutableIntStateOf(90) }
    var running by remember { mutableStateOf(false) }
    var timer by remember { mutableStateOf<CountDownTimer?>(null) }

    AlertDialog(
        onDismissRequest = { timer?.cancel(); onDismiss() },
        title = { Text("مؤقت الراحة") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(String.format(Locale.US, "%02d:%02d", remaining / 60, remaining % 60), style = MaterialTheme.typography.displayMedium, color = Accent)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(60, 90, 120, 180).forEach { value ->
                        FilterChip(selected = seconds == value, onClick = { timer?.cancel(); seconds = value; remaining = value; running = false }, label = { Text("${value/60}:${(value%60).toString().padStart(2,'0')}") })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (running) { timer?.cancel(); running = false }
                else {
                    running = true
                    timer = object : CountDownTimer(remaining * 1000L, 1000L) {
                        override fun onTick(millisUntilFinished: Long) { remaining = (millisUntilFinished / 1000L).toInt() }
                        override fun onFinish() { remaining = 0; running = false }
                    }.start()
                }
            }) { Text(if (running) "إيقاف" else "ابدأ") }
        },
        dismissButton = {
            TextButton(onClick = { timer?.cancel(); remaining = seconds; running = false }) { Text("إعادة") }
        }
    )
}
